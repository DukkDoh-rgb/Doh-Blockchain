# Roadmap

- [ ] Token extensions (permit, snapshot, burn/mint roles)
- [ ] Multisig or Timelock-based admin
- [ ] E2E deployment scripts for multiple networks
- [ ] Frontend dApp (wallet connect, mint/transfer UI)
