## Summary
Explain the change and why it’s needed.

## Changes
- [ ]

## Testing
- [ ] `npm test` passes
- [ ] Deployed to testnet (if applicable)

## Checklist
- [ ] Updated docs (README / docs/*)
- [ ] Added/updated tests
