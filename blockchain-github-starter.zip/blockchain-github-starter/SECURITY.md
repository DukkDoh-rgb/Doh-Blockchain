# Security Policy

**Do not** open public issues for security vulnerabilities.

- Report privately to: youremail@example.com
- We will acknowledge in 72 hours and aim to provide a fix ASAP.

**Note**: This template is for demo. Replace the contact with your own.
